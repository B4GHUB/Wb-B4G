export type ProtocolType = 'vless' | 'vmess' | 'trojan' | 'hysteria2' | 'tuic' | 'shadowsocks';

export type TransportType = 'tcp' | 'ws' | 'grpc' | 'httpupgrade' | 'splithttp';

export type SecurityType = 'reality' | 'tls' | 'none';

export type FingerprintType = 'chrome' | 'firefox' | 'safari' | 'edge' | 'ios' | 'random';

export interface ConfigBuilderState {
  protocol: ProtocolType;
  remark: string;
  server: string;
  port: number;
  uuid: string; // or password
  transport: TransportType;
  security: SecurityType;
  sni: string;
  host: string;
  path: string;
  serviceName: string;
  fingerprint: FingerprintType;
  flow: 'xtls-rprx-vision' | 'none';
  publicKey: string;
  shortId: string;
  spiderX: string;
  alpn: string;
  // Hysteria 2 specifics
  hy2PortHop: string;
  hy2Obfs: string;
  hy2ObfsPassword: string;
  // Shadowsocks
  ssMethod: string;
}

export interface PlanItem {
  id: string;
  title: string;
  subtitle: string;
  price: string;
  priceNum: number;
  period: string;
  traffic: string;
  users: string;
  protocols: string[];
  locations: string[];
  popular?: boolean;
  features: string[];
  recommendedFor: string;
  tag?: string;
}

export interface ServerLocation {
  code: string;
  name: string;
  flag: string;
  ping: number;
  status: 'active' | 'optimal' | 'busy';
  recommendedIsp: string[];
}

export interface TutorialGuide {
  id: string;
  title: string;
  category: 'vps' | 'xui' | 'protocols' | 'optimization';
  readTime: string;
  summary: string;
  steps: string[];
  tips: string;
  codeSnippet?: string;
}

export interface OperatorStatus {
  name: string;
  code: string;
  bestProtocol: string;
  statusText: string;
  health: 'excellent' | 'good' | 'moderate';
  pingRange: string;
  recommendedPort: string;
}
