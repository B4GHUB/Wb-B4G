/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ConfigBuilder } from './components/ConfigBuilder';
import { ConfigAnalyzer } from './components/ConfigAnalyzer';
import { ConfigStore } from './components/ConfigStore';
import { OperatorStatusSection } from './components/OperatorStatusSection';
import { TutorialsSection } from './components/TutorialsSection';
import { Footer } from './components/Footer';
import { CheckoutModal } from './components/CheckoutModal';
import { FreeTrialModal } from './components/FreeTrialModal';
import { PlanItem } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('builder');
  const [selectedPlan, setSelectedPlan] = useState<PlanItem | null>(null);
  const [freeTrialOpen, setFreeTrialOpen] = useState<boolean>(false);

  const scrollToSection = (id: string) => {
    setActiveTab(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenFreeTrial={() => setFreeTrialOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="flex-grow">
        {/* Hero Section with Live Stats & Fast Jumps */}
        <Hero
          onStartBuilding={() => scrollToSection('builder')}
          onExploreShop={() => scrollToSection('shop')}
          onOpenFreeTrial={() => setFreeTrialOpen(true)}
        />

        {/* The Star Feature: Interactive Config Builder & Generator */}
        <ConfigBuilder onPlanSelect={(planId) => scrollToSection('shop')} />

        {/* Config Analyzer / Decoder */}
        <ConfigAnalyzer />

        {/* Config Shop & Subscription Plans */}
        <ConfigStore
          onSelectPlan={(plan) => setSelectedPlan(plan)}
          onOpenFreeTrial={() => setFreeTrialOpen(true)}
        />

        {/* Real-time Operator Status & Latency Matrix */}
        <OperatorStatusSection />

        {/* In-depth Tutorials: VPS setup, X-UI/Marzban, client downloads, FAQs */}
        <TutorialsSection />
      </main>

      {/* Professional Tech Footer */}
      <Footer onOpenFreeTrial={() => setFreeTrialOpen(true)} />

      {/* Checkout and Instant Config Delivery Modal */}
      {selectedPlan && (
        <CheckoutModal
          plan={selectedPlan}
          onClose={() => setSelectedPlan(null)}
        />
      )}

      {/* Free Trial Modal (24h 2GB) */}
      <FreeTrialModal
        isOpen={freeTrialOpen}
        onClose={() => setFreeTrialOpen(false)}
      />
    </div>
  );
}

