import React, { useState } from 'react';
import QRCode from 'qrcode';
import { X, Gift, Check, Copy, QrCode, Sparkles, Wifi, ShieldCheck, Download } from 'lucide-react';
import { generateUUID } from '../utils/configParsers';

interface FreeTrialModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FreeTrialModal: React.FC<FreeTrialModalProps> = ({ isOpen, onClose }) => {
  const [selectedIsp, setSelectedIsp] = useState('mci');
  const [generatedUri, setGeneratedUri] = useState<string>('');
  const [qrUrl, setQrUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleGenerateTrial = () => {
    setIsLoading(true);
    setTimeout(() => {
      const uuid = generateUUID();
      let sni = 'speedtest.net';
      let proto = 'vless';
      let transport = 'tcp';
      let port = 443;
      let label = 'B4G-TEST-MCI⚡';

      if (selectedIsp === 'irancell') {
        sni = 'yahoo.com';
        label = 'B4G-TEST-IRANCELL🚀';
      } else if (selectedIsp === 'mokhaberat') {
        sni = 'zoom.us';
        label = 'B4G-TEST-TCI🛡️';
      } else if (selectedIsp === 'rightel') {
        sni = 'apple.com';
        label = 'B4G-TEST-RIGHTEL💎';
      }

      const uri = `vless://${uuid}@de.b4g-network.live:${port}?type=${transport}&security=reality&pbk=6XjQ_kP0w_gY17z9K8a3V5N1L9qQeR7tU3oW5xY7zA8&fp=chrome&sni=${sni}&sid=b49f20&spx=%2F&flow=xtls-rprx-vision#${encodeURIComponent(label)}`;
      
      setGeneratedUri(uri);

      QRCode.toDataURL(uri, { width: 240, margin: 2 })
        .then((url) => setQrUrl(url))
        .catch((e) => console.error(e));

      setIsLoading(false);
    }, 600);
  };

  const handleCopy = () => {
    if (!generatedUri) return;
    navigator.clipboard.writeText(generatedUri);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center space-y-2 mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-semibold">
            <Gift className="w-3.5 h-3.5" />
            <span>تست سرعت و کیفیت B4G</span>
          </div>
          <h3 className="text-xl font-extrabold text-white">دریافت کانفیگ تست رایگان ۲۴h</h3>
          <p className="text-xs text-slate-400">
            برای سنجش پینگ و کیفیت اتصال در محل زندگی خود، اپراتور سیم‌کارت یا اینترنت خانگی‌تان را انتخاب کنید.
          </p>
        </div>

        {/* Operator selection */}
        <div className="space-y-3 mb-5">
          <label className="block text-xs font-semibold text-slate-300">
            اپراتور اینترنت شما چیست؟
          </label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'mci', label: 'همراه اول' },
              { id: 'irancell', label: 'ایرانسل' },
              { id: 'mokhaberat', label: 'مخابرات (ADSL/فیبر)' },
              { id: 'rightel', label: 'رایتل / زیتل' },
            ].map((isp) => (
              <button
                key={isp.id}
                type="button"
                onClick={() => {
                  setSelectedIsp(isp.id);
                  setGeneratedUri('');
                }}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all border ${
                  selectedIsp === isp.id
                    ? 'bg-emerald-500/10 border-emerald-500 text-emerald-300 shadow-sm'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {isp.label}
              </button>
            ))}
          </div>
        </div>

        {!generatedUri ? (
          <button
            onClick={handleGenerateTrial}
            disabled={isLoading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-extrabold text-xs shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <span>در حال برقراری ارتباط با سرور...</span>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>تولید کانفیگ تست اختصاصی (حجم ۲ گیگ)</span>
              </>
            )}
          </button>
        ) : (
          <div className="space-y-4 pt-2 border-t border-slate-800 animate-fadeIn text-center">
            <div className="bg-white p-2.5 rounded-2xl inline-block mx-auto shadow-md">
              {qrUrl && <img src={qrUrl} alt="Trial QR" className="w-40 h-40 mx-auto" />}
            </div>

            <div className="text-right">
              <span className="text-[11px] font-bold text-slate-400 block mb-1">
                کد کانفیگ تست ۲۴ ساعته:
              </span>
              <div className="flex gap-2">
                <input
                  type="text"
                  readOnly
                  value={generatedUri}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-cyan-300 font-mono text-left select-all truncate"
                />
                <button
                  onClick={handleCopy}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1 flex-shrink-0 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'کپی شد' : 'کپی'}</span>
                </button>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-950 text-[11px] text-slate-400">
              اعتبار این کانفیگ ۲۴ ساعت و سقف ترافیک آن ۲ گیگابایت می‌باشد.
            </div>

            <button
              onClick={onClose}
              className="w-full py-2.5 rounded-xl bg-slate-800 text-white text-xs font-semibold hover:bg-slate-700 transition-colors"
            >
              بستن
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
