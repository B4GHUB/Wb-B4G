import React from 'react';
import { Terminal, Shield, Zap, Sparkles, CheckCircle2, ArrowDownCircle, Wifi, Server } from 'lucide-react';

interface HeroProps {
  onStartBuilding: () => void;
  onExploreShop: () => void;
  onOpenFreeTrial: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onStartBuilding, onExploreShop, onOpenFreeTrial }) => {
  return (
    <section className="relative pt-12 pb-16 overflow-hidden border-b border-slate-800/60">
      {/* Background glow effects */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 left-1/4 w-[400px] h-[250px] bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto space-y-6">
          
          {/* Top Status Pill */}
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-slate-900/90 border border-slate-700/80 shadow-inner">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-xs font-semibold text-slate-300">
              سیستم هوشمند B4G: تمام سرورها و پروتکل‌های Reality فعال هستند
            </span>
            <span className="hidden sm:inline text-xs text-cyan-400 font-mono">v4.8 Turbo</span>
          </div>

          {/* Main Headline */}
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight sm:leading-snug">
            پلتفرم تخصصی <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500">ساخت، بهینه‌سازی</span> و خرید کانفیگ‌های ضد فیلتر
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto">
            در پلتفرم <span className="font-bold text-white font-mono">B4G</span> یا با ژنراتور پیشرفته ما کانفیگ سفارشی VLESS Reality و Hysteria 2 بسازید، یا از پلن‌های فوق پرسرعت سرورهای اختصاصی آلمان و هلند با پینگ پایین استفاده کنید.
          </p>

          {/* Key Trust Pillars */}
          <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 pt-2 text-xs sm:text-sm text-slate-300">
            <div className="flex items-center gap-1.5 bg-slate-900/60 px-3 py-1.5 rounded-xl border border-slate-800">
              <Shield className="w-4 h-4 text-cyan-400" />
              <span>فناوری XTLS Reality Vision</span>
            </div>
            <div className="flex items-center gap-1.5 bg-slate-900/60 px-3 py-1.5 rounded-xl border border-slate-800">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>پروتکل گیمینگ Hysteria 2 UDP</span>
            </div>
            <div className="flex items-center gap-1.5 bg-slate-900/60 px-3 py-1.5 rounded-xl border border-slate-800">
              <Wifi className="w-4 h-4 text-emerald-400" />
              <span>پینگ پایدار ۳۵ تا ۵۰ میلی‌ثانیه</span>
            </div>
          </div>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-4">
            <button
              id="hero-start-builder-btn"
              onClick={onStartBuilding}
              className="w-full sm:w-auto flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold shadow-lg shadow-cyan-500/25 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Terminal className="w-5 h-5" />
              <span>ژنراتور ساخت کانفیگ</span>
            </button>

            <button
              id="hero-explore-shop-btn"
              onClick={onExploreShop}
              className="w-full sm:w-auto flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-100 font-semibold border border-slate-700 transition-all hover:border-slate-600"
            >
              <span>مشاهده پلن‌های خرید کانفیگ</span>
              <ArrowDownCircle className="w-5 h-5 text-cyan-400" />
            </button>

            <button
              id="hero-free-trial-btn"
              onClick={onOpenFreeTrial}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30 transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span>تست رایگان ۲۴ ساعته</span>
            </button>
          </div>

          {/* Live Node Ticker */}
          <div className="pt-6">
            <div className="inline-flex flex-wrap items-center justify-center gap-3 sm:gap-6 px-4 py-2 rounded-2xl bg-slate-900/40 border border-slate-800/80 text-xs text-slate-400">
              <span className="flex items-center gap-1.5 text-slate-300 font-medium">
                <Server className="w-3.5 h-3.5 text-cyan-400" />
                وضعیت سرورهای ابری:
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                <span>آلمان (Hetzner): 42ms</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                <span>هلند: 48ms</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                <span>فنلاند: 51ms</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                <span>ترکیه: 36ms</span>
              </span>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
