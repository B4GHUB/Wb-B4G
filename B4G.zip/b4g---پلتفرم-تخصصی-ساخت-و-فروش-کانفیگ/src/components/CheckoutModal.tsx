import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { X, Check, Copy, Shield, QrCode, Download, Send, CreditCard, Coins, Smartphone, ArrowRight, ExternalLink } from 'lucide-react';
import { PlanItem } from '../types';
import { generateUUID } from '../utils/configParsers';

interface CheckoutModalProps {
  plan: PlanItem | null;
  onClose: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ plan, onClose }) => {
  const [step, setStep] = useState<'details' | 'success'>('details');
  const [selectedApp, setSelectedApp] = useState('v2rayNG (Android)');
  const [selectedProtocol, setSelectedProtocol] = useState('VLESS Reality');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'crypto' | 'telegram'>('card');
  const [telegramId, setTelegramId] = useState('');
  const [generatedSubUrl, setGeneratedSubUrl] = useState('');
  const [generatedConfigUri, setGeneratedConfigUri] = useState('');
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [copiedSub, setCopiedSub] = useState(false);
  const [copiedConfig, setCopiedConfig] = useState(false);

  if (!plan) return null;

  const handleCompleteOrder = () => {
    const userUuid = generateUUID();
    const token = Math.random().toString(36).substring(2, 12);
    const subUrl = `https://sub.b4g-network.live/sub/${token}?plan=${plan.id}&client=${encodeURIComponent(selectedApp)}`;
    const configUri = `vless://${userUuid}@de.b4g-network.live:443?type=tcp&security=reality&pbk=6XjQ_kP0w_gY17z9K8a3V5N1L9qQeR7tU3oW5xY7zA8&fp=chrome&sni=speedtest.net&sid=b49f20&spx=%2F&flow=xtls-rprx-vision#B4G-VIP-${encodeURIComponent(plan.title.replace(/\s+/g, '-'))}⚡`;

    setGeneratedSubUrl(subUrl);
    setGeneratedConfigUri(configUri);

    // Generate real QR code for the subscription
    QRCode.toDataURL(configUri, { width: 260, margin: 2 })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.error(err));

    setStep('success');
  };

  const copyToClipboard = (text: string, type: 'sub' | 'config') => {
    navigator.clipboard.writeText(text);
    if (type === 'sub') {
      setCopiedSub(true);
      setTimeout(() => setCopiedSub(false), 2000);
    } else {
      setCopiedConfig(true);
      setTimeout(() => setCopiedConfig(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl relative my-8">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {step === 'details' ? (
          <div className="space-y-6">
            
            {/* Header */}
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 text-xs font-semibold mb-2">
                <Shield className="w-3.5 h-3.5" />
                <span>سفارش کانفیگ اختصاصی B4G</span>
              </div>
              <h3 className="text-xl font-extrabold text-white">{plan.title}</h3>
              <p className="text-xs text-slate-400 mt-1">{plan.subtitle}</p>
            </div>

            {/* Plan Summary Card */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 block">مبلغ قابل پرداخت:</span>
                <span className="text-2xl font-extrabold text-cyan-400 font-mono">{plan.price}</span>
                <span className="text-xs text-slate-400 mr-1">تومان</span>
              </div>
              <div className="text-left text-xs text-slate-300 space-y-1">
                <div>حجم: <span className="font-bold text-white font-mono">{plan.traffic}</span></div>
                <div>مدت: <span className="font-bold text-white">{plan.period}</span></div>
                <div>کاربر: <span className="font-bold text-white">{plan.users}</span></div>
              </div>
            </div>

            {/* Application Preference */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                دستگاه یا نرم‌افزار مورد استفاده شما:
              </label>
              <select
                value={selectedApp}
                onChange={(e) => setSelectedApp(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="v2rayNG (Android)">v2rayNG (اندروید - پیشنهادی)</option>
                <option value="Streisand (iOS)">Streisand (آیفون iOS)</option>
                <option value="FoXray (iOS / Mac)">FoXray (آیفون / مک)</option>
                <option value="NekoRay (Windows)">NekoRay (ویندوز با هسته Xray)</option>
                <option value="Sing-box (Cross-platform)">Sing-box (تمامی سیستم‌عامل‌ها)</option>
                <option value="Clash Verge (PC / Mac)">Clash Verge Rev</option>
              </select>
            </div>

            {/* Protocol Preference */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                پروتکل پیشنهادی سرور:
              </label>
              <div className="grid grid-cols-2 gap-2">
                {['VLESS Reality', 'Hysteria 2 UDP', 'Trojan gRPC', 'VMess CDN'].map((proto) => (
                  <button
                    key={proto}
                    type="button"
                    onClick={() => setSelectedProtocol(proto)}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition-all border ${
                      selectedProtocol === proto
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                    }`}
                  >
                    {proto}
                  </button>
                ))}
              </div>
            </div>

            {/* Payment Method Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                روش پرداخت:
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    paymentMethod === 'card'
                      ? 'bg-cyan-500/10 border-cyan-500 text-cyan-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <CreditCard className="w-4 h-4 mx-auto mb-1 text-cyan-400" />
                  <span className="text-[11px] font-bold block">کارت به کارت</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('crypto')}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    paymentMethod === 'crypto'
                      ? 'bg-cyan-500/10 border-cyan-500 text-cyan-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <Coins className="w-4 h-4 mx-auto mb-1 text-amber-400" />
                  <span className="text-[11px] font-bold block">تتر (USDT)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('telegram')}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    paymentMethod === 'telegram'
                      ? 'bg-cyan-500/10 border-cyan-500 text-cyan-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <Send className="w-4 h-4 mx-auto mb-1 text-blue-400" />
                  <span className="text-[11px] font-bold block">پشتیبان تلگرام</span>
                </button>
              </div>

              {/* Payment Details */}
              <div className="mt-3 p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1 font-mono text-right">
                {paymentMethod === 'card' && (
                  <>
                    <div className="text-slate-400">شماره کارت بانکی B4G Network:</div>
                    <div className="font-bold text-white text-sm tracking-wider">۶۰۳۷-۹۹۷۵-۱۲۳۴-۵۶۷۸</div>
                    <div className="text-[11px] text-slate-400 font-sans">به نام مدیر سرورهای B4G</div>
                  </>
                )}
                {paymentMethod === 'crypto' && (
                  <>
                    <div className="text-slate-400">آدرس ولت USDT (شبکه Tron TRC-20):</div>
                    <div className="font-bold text-white text-[11px] break-all select-all">
                      TYDVs8i9Xb4gNetWorkSecureServerPay77Q
                    </div>
                  </>
                )}
                {paymentMethod === 'telegram' && (
                  <div className="font-sans text-xs">
                    آیدی تلگرام جهت پرداخت و هماهنگی فوری: <a href="https://t.me/b4g_support" target="_blank" rel="noopener noreferrer" className="text-cyan-400 font-bold underline">@b4g_support</a>
                  </div>
                )}
              </div>
            </div>

            {/* Telegram handle input */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                آیدی تلگرام یا شماره موبایل (جهت پیگیری اشتراک):
              </label>
              <input
                type="text"
                value={telegramId}
                onChange={(e) => setTelegramId(e.target.value)}
                placeholder="@your_id یا 0912..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* Submit CTA */}
            <button
              onClick={handleCompleteOrder}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-extrabold text-sm shadow-lg shadow-cyan-500/20 transition-all flex items-center justify-center gap-2"
            >
              <span>تکمیل سفارش و دریافت آنی لینک کانفیگ</span>
              <ArrowRight className="w-4 h-4 rotate-180" />
            </button>
          </div>
        ) : (
          /* Step: Success / Delivery */
          <div className="space-y-6 text-center animate-fadeIn">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
              <Check className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-xl font-extrabold text-white">اشتراک B4G با موفقیت ایجاد شد!</h3>
              <p className="text-xs text-slate-300 mt-1">
                کانفیگ اختصاصی شما روی سرور آلمان فعال گردید و آماده اتصال در {selectedApp} است.
              </p>
            </div>

            {/* QR Code */}
            <div className="bg-white p-3 rounded-2xl inline-block mx-auto shadow-md">
              {qrDataUrl ? (
                <img src={qrDataUrl} alt="VIP Subscription QR" className="w-48 h-48 mx-auto" />
              ) : (
                <div className="w-48 h-48 flex items-center justify-center bg-slate-200">
                  <QrCode className="w-8 h-8 text-slate-600" />
                </div>
              )}
            </div>

            {/* Links and copy */}
            <div className="space-y-3 text-right">
              {/* Direct Config */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 block mb-1">
                  کد مستقیم کانفیگ VLESS Reality (تک کانفیگ):
                </span>
                <div className="flex gap-2">
                  <input
                    type="text"
                    readOnly
                    value={generatedConfigUri}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-cyan-300 font-mono text-left select-all truncate"
                  />
                  <button
                    onClick={() => copyToClipboard(generatedConfigUri, 'config')}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1 flex-shrink-0 transition-colors"
                  >
                    {copiedConfig ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedConfig ? 'کپی شد' : 'کپی'}</span>
                  </button>
                </div>
              </div>

              {/* Sub Link */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 block mb-1">
                  لینک هوشمند سابسکریپشن (آپدیت خودکار کلیه سرورها):
                </span>
                <div className="flex gap-2">
                  <input
                    type="text"
                    readOnly
                    value={generatedSubUrl}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-emerald-300 font-mono text-left select-all truncate"
                  />
                  <button
                    onClick={() => copyToClipboard(generatedSubUrl, 'sub')}
                    className="px-3 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1 flex-shrink-0 transition-colors"
                  >
                    {copiedSub ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedSub ? 'کپی شد' : 'کپی ساب'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Support instruction */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 flex items-center justify-between">
              <span>نیاز به راهنمایی در اتصال دارید؟</span>
              <a
                href="https://t.me/b4g_support"
                target="_blank"
                rel="noopener noreferrer"
                className="text-cyan-400 font-bold hover:underline flex items-center gap-1"
              >
                <span>پشتیبانی B4G در تلگرام</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-white text-xs font-bold transition-colors"
            >
              بستن پنجره
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
