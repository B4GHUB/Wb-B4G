import React, { useState } from 'react';
import { Cpu, Search, CheckCircle, AlertTriangle, ArrowRight, ShieldCheck, Server, Globe, Key, Layers, RefreshCw } from 'lucide-react';
import { parseConfigURI, ParsedConfig } from '../utils/configParsers';

interface ConfigAnalyzerProps {
  onLoadIntoBuilder?: (parsed: ParsedConfig) => void;
}

export const ConfigAnalyzer: React.FC<ConfigAnalyzerProps> = () => {
  const [inputRaw, setInputRaw] = useState('');
  const [parsed, setParsed] = useState<ParsedConfig | null>(null);
  const [analyzed, setAnalyzed] = useState(false);

  const sampleConfigs = [
    'vless://3a1f89c0-e75b-4899-b1d5-912a7f5390c1@de.b4g-network.live:443?type=tcp&security=reality&pbk=6XjQ_kP0w_gY17z9K8a3V5N1L9qQeR7tU3oW5xY7zA8&fp=chrome&sni=speedtest.net&sid=b49f20&spx=%2F&flow=xtls-rprx-vision#B4G-GERMANY-REALITY%E2%9A%A1',
    'vmess://eyJhZGQiOiJjZG4uYjRnLXByb3h5LmNvbSIsImFpZCI6IjAiLCJob3N0IjoiY2RuLmI0Zy1wcm94eS5jb20iLCJpZCI6ImI0Z2FiY2QtMTIzNC01Njc4LTkwMTItMTIzNDU2Nzg5MGFiIiwibmV0Ijoid3MiLCJwYXRoIjoiL2I0Zy13cyIsInBvcnQiOiI0NDMiLCJwcyI6IkI0Ry1WTUVTUy1DRE4iLCJzY3kiOiJhdXRvIiwic25pIjoiY2RuLmI0Zy1wcm94eS5jb20iLCJ0bHMiOiJ0bHMiLCJ0eXBlIjoibm9uZSIsInYiOiIyIn0=',
  ];

  const handleAnalyze = () => {
    if (!inputRaw.trim()) return;
    const result = parseConfigURI(inputRaw);
    setParsed(result);
    setAnalyzed(true);
  };

  const handleReset = () => {
    setInputRaw('');
    setParsed(null);
    setAnalyzed(false);
  };

  return (
    <section id="analyzer" className="py-12 bg-slate-900/40 border-y border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-semibold mb-3">
            <Cpu className="w-3.5 h-3.5" />
            <span>آنالیزور و عیب‌یاب هوشمند کانفیگ</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            دیکودر و <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">کالبدشکافی کانفیگ‌های V2Ray</span>
          </h2>
          <p className="mt-2 text-sm text-slate-400">
            کانفیگ VLESS، VMess، Hysteria یا Trojan خود را در کادر زیر قرار دهید تا پارامترها، سلامت امنیتی و تنظیمات استتار آن رمزگشایی و تحلیل شود.
          </p>
        </div>

        <div className="max-w-4xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-7 shadow-xl space-y-5">
          {/* Input field */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              لینک کانفیگ (Paste Raw URI)
            </label>
            <div className="relative">
              <textarea
                rows={3}
                value={inputRaw}
                onChange={(e) => setInputRaw(e.target.value)}
                placeholder="vless://... یا vmess://... یا hysteria2://..."
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl p-3.5 text-xs text-cyan-200 font-mono text-left focus:outline-none focus:border-cyan-500 transition-colors"
              />
            </div>
          </div>

          {/* Buttons & Presets */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="text-slate-400">نمونه تستی:</span>
              <button
                type="button"
                onClick={() => {
                  setInputRaw(sampleConfigs[0]);
                  const res = parseConfigURI(sampleConfigs[0]);
                  setParsed(res);
                  setAnalyzed(true);
                }}
                className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-xs transition-colors"
              >
                نمونه VLESS Reality
              </button>
              <button
                type="button"
                onClick={() => {
                  setInputRaw(sampleConfigs[1]);
                  const res = parseConfigURI(sampleConfigs[1]);
                  setParsed(res);
                  setAnalyzed(true);
                }}
                className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-xs transition-colors"
              >
                نمونه VMess Base64
              </button>
            </div>

            <div className="flex items-center gap-2">
              {analyzed && (
                <button
                  type="button"
                  onClick={handleReset}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>پاک کردن</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleAnalyze}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white text-xs font-bold shadow-md shadow-blue-500/20 transition-all flex items-center gap-1.5"
              >
                <Search className="w-4 h-4" />
                <span>شروع آنالیز و استخراج</span>
              </button>
            </div>
          </div>

          {/* Analysis Result */}
          {analyzed && parsed && (
            <div className="pt-6 border-t border-slate-800/90 space-y-4 animate-fadeIn">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  <span className="font-bold text-sm text-white">نتیجه کالبدشکافی مشخصات فنی</span>
                </div>
                <span className="px-2.5 py-1 rounded-md bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-mono font-bold uppercase">
                  {parsed.protocol}
                </span>
              </div>

              {/* Parsed Attributes Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-slate-400 flex items-center gap-1.5 mb-1">
                    <Server className="w-3.5 h-3.5 text-cyan-400" />
                    <span>نام و ریمارک (Remark)</span>
                  </div>
                  <div className="font-semibold text-slate-200 truncate font-mono">
                    {parsed.remark || 'بدون نام'}
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-slate-400 flex items-center gap-1.5 mb-1">
                    <Globe className="w-3.5 h-3.5 text-cyan-400" />
                    <span>آدرس سرور و پورت</span>
                  </div>
                  <div className="font-semibold text-slate-200 font-mono">
                    {parsed.server}:{parsed.port}
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-slate-400 flex items-center gap-1.5 mb-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                    <span>رمزنگاری و امنیت (Security)</span>
                  </div>
                  <div className="font-semibold text-emerald-400 uppercase font-mono">
                    {parsed.security}
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-slate-400 flex items-center gap-1.5 mb-1">
                    <Layers className="w-3.5 h-3.5 text-cyan-400" />
                    <span>لایه انتقال (Transport)</span>
                  </div>
                  <div className="font-semibold text-slate-200 uppercase font-mono">
                    {parsed.transport}
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-slate-400 flex items-center gap-1.5 mb-1">
                    <Globe className="w-3.5 h-3.5 text-cyan-400" />
                    <span>دامنه استتار (SNI)</span>
                  </div>
                  <div className="font-semibold text-slate-200 font-mono">
                    {parsed.sni || 'ندارد (پیش‌فرض سرور)'}
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-slate-400 flex items-center gap-1.5 mb-1">
                    <Key className="w-3.5 h-3.5 text-cyan-400" />
                    <span>شناسه کاربر (UUID)</span>
                  </div>
                  <div className="font-semibold text-slate-200 font-mono truncate text-[11px]">
                    {parsed.uuid ? `${parsed.uuid.substring(0, 16)}...` : 'خالی'}
                  </div>
                </div>
              </div>

              {/* Assessment / Diagnostic Note */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-start gap-3">
                <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                <div className="text-xs text-slate-300 space-y-1">
                  <div className="font-bold text-white">ارزیابی فنی ساختار کانفیگ توسط مهندس شبکه B4G:</div>
                  <p className="text-slate-400 leading-relaxed">
                    {parsed.security === 'reality'
                      ? 'این کانفیگ از مکانیزم Reality با استتار TLS استفاده می‌کند که در حال حاضر بالاترین مقاومت را در برابر سیستم فیلترینگ همراه اول و ایرانسل دارد.'
                      : parsed.transport === 'ws'
                      ? 'این کانفیگ از پروتکل بر پایه وب‌سوکت بهره می‌برد. برای عملکرد بدون افت، استفاده از آی‌پی‌های تمیز کلودفلر توصیه می‌شود.'
                      : 'ساختار کانفیگ استاندارد است و در کلیه کلاینت‌های v2rayNG، Sing-box و Nekoray قابل استفاده می‌باشد.'}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

      </div>
    </section>
  );
};
