import React, { useState } from 'react';
import { BookOpen, Terminal, ChevronDown, ChevronUp, Copy, Check, Download, ExternalLink, ShieldCheck, Sparkles } from 'lucide-react';
import { TUTORIAL_GUIDES, CLIENT_DOWNLOADS, FAQS } from '../data/mockData';

export const TutorialsSection: React.FC = () => {
  const [activeGuideId, setActiveGuideId] = useState<string>(TUTORIAL_GUIDES[0].id);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const currentGuide = TUTORIAL_GUIDES.find((g) => g.id === activeGuideId) || TUTORIAL_GUIDES[0];

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <section id="tutorials" className="py-16 bg-slate-950 text-slate-100 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-2">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-semibold">
            <BookOpen className="w-3.5 h-3.5" />
            <span>آکادمی مهندسی شبکه B4G</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            مرجع جامع <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">آموزش ساخت و راه‌اندازی کانفیگ</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            یاد بگیرید چگونه سرور مجازی (VPS) شخصی خود را به یک پروکسی نامحدود VLESS Reality یا Hysteria 2 تبدیل کنید.
          </p>
        </div>

        {/* Guides Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start mb-16">
          
          {/* Guide Selector (4 cols) */}
          <div className="lg:col-span-4 space-y-2">
            <span className="text-xs font-bold text-slate-400 block mb-2 px-1">سرفصل‌های آموزشی:</span>
            {TUTORIAL_GUIDES.map((guide) => {
              const isSelected = guide.id === activeGuideId;
              return (
                <button
                  key={guide.id}
                  onClick={() => setActiveGuideId(guide.id)}
                  className={`w-full text-right p-4 rounded-2xl border transition-all text-xs ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500/70 shadow-lg shadow-cyan-500/5'
                      : 'bg-slate-950/80 border-slate-800 hover:bg-slate-900/60 hover:border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] uppercase font-bold text-cyan-400">
                      {guide.category.toUpperCase()}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">{guide.readTime}</span>
                  </div>
                  <h4 className={`font-bold text-sm leading-snug ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                    {guide.title}
                  </h4>
                </button>
              );
            })}
          </div>

          {/* Active Guide Content (8 cols) */}
          <div className="lg:col-span-8 bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-bold">
                  آموزش تخصصی
                </span>
                <span>زمان مطالعه: {currentGuide.readTime}</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-extrabold text-white leading-snug">
                {currentGuide.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
                {currentGuide.summary}
              </p>
            </div>

            {/* Steps list */}
            <div className="space-y-3">
              <span className="text-xs font-bold text-slate-200 block">مراحل گام‌به‌گام پیاده‌سازی:</span>
              <div className="space-y-2">
                {currentGuide.steps.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-300">
                    <span className="flex-shrink-0 w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-400 font-mono font-bold flex items-center justify-center text-xs">
                      {idx + 1}
                    </span>
                    <span className="leading-relaxed mt-0.5">{step}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Code Snippet Box */}
            {currentGuide.codeSnippet && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                    <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                    <span>دستور نصب در ترمینال سرور:</span>
                  </span>
                  <button
                    onClick={() => handleCopyCode(currentGuide.codeSnippet!)}
                    className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                  >
                    {copiedCode === currentGuide.codeSnippet ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">کپی شد!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>کپی دستور</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs text-emerald-400 select-all overflow-x-auto text-left">
                  {currentGuide.codeSnippet}
                </div>
              </div>
            )}

            {/* Pro Tip Box */}
            <div className="p-4 rounded-2xl bg-cyan-950/20 border border-cyan-800/40 flex items-start gap-3 text-xs text-slate-300">
              <Sparkles className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-cyan-400 block mb-0.5">نکته حرفه‌ای B4G:</span>
                <p className="leading-relaxed text-slate-300">{currentGuide.tips}</p>
              </div>
            </div>
          </div>

        </div>

        {/* Client Software Downloads */}
        <div className="mb-16">
          <div className="text-center max-w-2xl mx-auto mb-8">
            <h3 className="text-xl sm:text-2xl font-bold text-white">نرم‌افزارهای پیشنهادی جهت اجرای کانفیگ</h3>
            <p className="text-xs text-slate-400 mt-1">
              جهت اتصال به کانفیگ‌های ساخته شده در B4G، از اپلیکیشن‌های رسمی و متن‌باز زیر استفاده کنید.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {CLIENT_DOWNLOADS.map((client, idx) => (
              <div
                key={idx}
                className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between hover:border-slate-700 transition-all"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-cyan-400">{client.platform}</span>
                    <span className="text-[10px] font-semibold bg-cyan-500/10 text-cyan-300 px-2 py-0.5 rounded-full border border-cyan-500/20">
                      {client.badge}
                    </span>
                  </div>
                  <h4 className="font-bold text-sm text-white">{client.name}</h4>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">{client.desc}</p>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-800/80">
                  <a
                    href={client.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <span>دانلود مستقیم</span>
                    <ExternalLink className="w-3 h-3 text-cyan-400" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* FAQs */}
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <h3 className="text-xl sm:text-2xl font-bold text-white">سوالات متداول درباره ساخت و خرید کانفیگ</h3>
          </div>

          <div className="space-y-3">
            {FAQS.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={idx}
                  className="rounded-2xl bg-slate-900/70 border border-slate-800 overflow-hidden transition-all"
                >
                  <button
                    type="button"
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full p-4 text-right flex items-center justify-between gap-3 text-sm font-bold text-slate-200 hover:text-white"
                  >
                    <span>{faq.q}</span>
                    {isOpen ? <ChevronUp className="w-4 h-4 text-cyan-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </button>

                  {isOpen && (
                    <div className="px-4 pb-4 text-xs text-slate-400 leading-relaxed border-t border-slate-800/60 pt-3 animate-fadeIn">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
};
