import React from 'react';
import { Shield, Send, Heart, Terminal, Cpu, ShoppingBag, Activity, BookOpen } from 'lucide-react';

interface FooterProps {
  onOpenFreeTrial: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenFreeTrial }) => {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 text-white shadow-md">
                <Shield className="w-4 h-4" />
              </div>
              <span className="font-extrabold text-xl text-white font-mono tracking-wider">B4G</span>
              <span className="text-[10px] bg-cyan-500/10 text-cyan-400 px-1.5 py-0.5 rounded border border-cyan-500/20 font-mono">
                CONFIG PLATFORM
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-md">
              پلتفرم <span className="text-white font-semibold">B4G</span> مرجع تخصصی ساخت، مهندسی پروتکل‌های رمزنگاری شده V2Ray، XTLS Reality و Hysteria 2 و فروش سرورهای اختصاصی پرسرعت و ضد اختلال است.
            </p>
            <div className="pt-2 flex items-center gap-3">
              <a
                href="https://t.me/b4g_support"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs font-medium transition-colors"
              >
                <Send className="w-3.5 h-3.5 text-cyan-400" />
                <span>ارتباط با پشتیبان تلگرام: @b4g_support</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-200 block mb-2">ابزارهای B4G:</span>
            <ul className="space-y-1.5">
              <li>
                <button onClick={() => scrollTo('builder')} className="hover:text-cyan-400 transition-colors">
                  ساخت کانفیگ سفارشی VLESS
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('analyzer')} className="hover:text-cyan-400 transition-colors">
                  آنالیزور و دیکودر کانفیگ
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('shop')} className="hover:text-cyan-400 transition-colors">
                  پلن‌های خرید کانفیگ پرسرعت
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('operators')} className="hover:text-cyan-400 transition-colors">
                  وضعیت لحظه‌ای پینگ اپراتورها
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('tutorials')} className="hover:text-cyan-400 transition-colors">
                  آموزش نصب 3X-UI و Hysteria 2
                </button>
              </li>
            </ul>
          </div>

          {/* Guarantee & Trial */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-200 block">ضمانت و تست:</span>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              کلیه کانفیگ‌های ارائه‌شده دارای تست ۲۴ ساعته رایگان، پشتیبانی آنلاین و مجهز به آی‌پی‌های بدون قطعی می‌باشند.
            </p>
            <button
              onClick={onOpenFreeTrial}
              className="w-full py-2 px-3 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold transition-all text-center"
            >
              دریافت کانفیگ تستی رایگان ۲۴h
            </button>
          </div>

        </div>

        {/* Disclaimer & Copyright */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400">
          <div>
            © 2026 پلتفرم مهندسی کانفیگ B4G. تمامی حقوق محفوظ است.
          </div>
          <div className="flex items-center gap-1">
            <span>توسعه یافته برای آزادی اینترنت و دسترسی آزاد به اطلاعات</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
