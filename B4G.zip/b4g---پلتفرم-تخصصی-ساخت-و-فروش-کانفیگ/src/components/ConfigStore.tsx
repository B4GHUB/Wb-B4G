import React, { useState } from 'react';
import { ShoppingBag, Check, Shield, Zap, Sparkles, Server, ArrowLeft, Star, HeartHandshake, Headphones } from 'lucide-react';
import { PlanItem } from '../types';
import { SHOP_PLANS, SERVER_LOCATIONS } from '../data/mockData';

interface ConfigStoreProps {
  onSelectPlan: (plan: PlanItem) => void;
  onOpenFreeTrial: () => void;
}

export const ConfigStore: React.FC<ConfigStoreProps> = ({ onSelectPlan, onOpenFreeTrial }) => {
  const [filter, setFilter] = useState<'all' | 'popular' | 'gaming' | 'unlimited'>('all');

  const filteredPlans = SHOP_PLANS.filter((plan) => {
    if (filter === 'popular') return plan.popular;
    if (filter === 'gaming') return plan.id === 'gaming';
    if (filter === 'unlimited') return plan.id === 'unlimited';
    return true;
  });

  return (
    <section id="shop" className="py-16 bg-slate-950 relative overflow-hidden">
      {/* Subtle background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[300px] bg-cyan-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-semibold">
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>پلن‌های آماده و سرورهای اختصاصی B4G</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            خرید کانفیگ‌های اختصاصی با <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500">تحویل آنی و هوشمند</span>
          </h2>
          <p className="text-sm sm:text-base text-slate-400 leading-relaxed max-w-2xl mx-auto">
            سرورهای اختصاصی هرتزنر آلمان و هلند با پورت ۱۰ گیگابیت، آی‌پی تمیز و گارانتی اتصال بدون قطعی. تحویل لینک هوشمند سابسکریپشن همراه با کیوآرکد بلافاصله پس از سفارش.
          </p>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-3">
            <button
              onClick={() => setFilter('all')}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${
                filter === 'all'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              همه پلن‌ها
            </button>
            <button
              onClick={() => setFilter('popular')}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${
                filter === 'popular'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              محبوب‌ترین (Reality)
            </button>
            <button
              onClick={() => setFilter('gaming')}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${
                filter === 'gaming'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              گیمینگ (Hysteria 2)
            </button>
            <button
              onClick={() => setFilter('unlimited')}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${
                filter === 'unlimited'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              نامحدود ترافیک
            </button>
          </div>
        </div>

        {/* Plans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
          {filteredPlans.map((plan) => {
            const isPopular = plan.popular;
            return (
              <div
                key={plan.id}
                id={`plan-card-${plan.id}`}
                className={`flex flex-col justify-between rounded-3xl p-6 transition-all relative ${
                  isPopular
                    ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border-2 border-cyan-500/80 shadow-2xl shadow-cyan-500/10 scale-[1.02]'
                    : 'bg-slate-900/70 border border-slate-800/90 hover:border-slate-700'
                }`}
              >
                {/* Popular Tag */}
                {plan.tag && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="px-3 py-1 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-extrabold text-[11px] shadow-md shadow-cyan-500/30">
                      {plan.tag}
                    </span>
                  </div>
                )}

                <div>
                  {/* Title & Subtitle */}
                  <div className="mb-4">
                    <h3 className="text-lg font-extrabold text-white">{plan.title}</h3>
                    <p className="text-xs text-slate-400 mt-1 min-h-[32px]">{plan.subtitle}</p>
                  </div>

                  {/* Price */}
                  <div className="mb-5 pb-5 border-b border-slate-800/80">
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-extrabold text-white font-mono">{plan.price}</span>
                      <span className="text-xs text-slate-400 font-medium">تومان / {plan.period}</span>
                    </div>
                  </div>

                  {/* Quick Specs */}
                  <div className="grid grid-cols-2 gap-2 mb-5 text-xs">
                    <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                      <span className="block text-slate-500 text-[10px]">ترافیک:</span>
                      <span className="font-bold text-slate-200">{plan.traffic}</span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                      <span className="block text-slate-500 text-[10px]">تعداد کاربر:</span>
                      <span className="font-bold text-slate-200">{plan.users}</span>
                    </div>
                  </div>

                  {/* Features List */}
                  <div className="space-y-2.5 mb-6">
                    <span className="block text-[11px] font-bold text-slate-400">ویژگی‌های این پلن:</span>
                    {plan.features.map((feat, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                        <Check className="w-3.5 h-3.5 text-cyan-400 mt-0.5 flex-shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Buy Button */}
                <div className="pt-2">
                  <button
                    onClick={() => onSelectPlan(plan)}
                    className={`w-full py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                      isPopular
                        ? 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-lg shadow-cyan-500/20'
                        : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <span>خرید و تحویل آنی</span>
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Server Locations Matrix */}
        <div className="mt-16 bg-slate-900/60 border border-slate-800 rounded-3xl p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
            <div>
              <div className="flex items-center gap-2">
                <Server className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-base sm:text-lg text-white">لوکیشن‌های سرور فعال در B4G</h3>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                کلیه دیتاسنترها با پهنای باند اختصاصی و مسیرهای بهینه‌شده به شبکه‌های ایرانسل، همراه اول و مخابرات متصل هستند.
              </p>
            </div>
            
            <button
              onClick={onOpenFreeTrial}
              className="px-4 py-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold transition-all flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4" />
              <span>تست پینگ رایگان قبل از خرید</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {SERVER_LOCATIONS.map((loc) => (
              <div
                key={loc.code}
                className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800/90 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{loc.flag}</span>
                  <div>
                    <div className="font-bold text-sm text-slate-200">{loc.name}</div>
                    <div className="text-[11px] text-slate-400">
                      مناسب: {loc.recommendedIsp.join('، ')}
                    </div>
                  </div>
                </div>

                <div className="text-left">
                  <div className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span>~{loc.ping}ms</span>
                  </div>
                  <span className="text-[10px] text-slate-500 uppercase">Status: {loc.status}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Guarantees row */}
          <div className="mt-8 pt-6 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-3 gap-4 text-center sm:text-right">
            <div className="flex items-center gap-3 justify-center sm:justify-start">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400 flex-shrink-0">
                <Shield className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <div className="font-bold text-slate-200">گارانتی عدم قطعی و تعویض</div>
                <div className="text-slate-400 text-[11px]">پشتیبانی کامل تا روز آخر دوره</div>
              </div>
            </div>

            <div className="flex items-center gap-3 justify-center sm:justify-start">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 flex-shrink-0">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <div className="font-bold text-slate-200">تحویل آنی خودکار</div>
                <div className="text-slate-400 text-[11px]">لینک سابسکریپشن و کیوآرکد بلافاصله</div>
              </div>
            </div>

            <div className="flex items-center gap-3 justify-center sm:justify-start">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 flex-shrink-0">
                <Headphones className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <div className="font-bold text-slate-200">پشتیبانی ۲۴ ساعته تلگرام</div>
                <div className="text-slate-400 text-[11px]">ارتباط مستقیم با کارشناس کانفیگ</div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
