import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { 
  Terminal, 
  Copy, 
  Check, 
  QrCode, 
  RefreshCw, 
  Download, 
  Sliders, 
  ShieldCheck, 
  Zap, 
  Layers, 
  FileText, 
  Share2, 
  CheckCircle2, 
  AlertCircle,
  Key,
  Globe,
  Radio,
  ExternalLink
} from 'lucide-react';
import { ConfigBuilderState, ProtocolType, TransportType, SecurityType, FingerprintType } from '../types';
import { DEFAULT_BUILDER_STATE, PRESET_CONFIGS, POPULAR_SNI_LIST } from '../data/mockData';
import { buildConfigURI, buildClashMetaYaml, buildSingboxJson, generateUUID, generateShortId, generateRandomSecret } from '../utils/configParsers';

interface ConfigBuilderProps {
  onPlanSelect?: (planId: string) => void;
}

export const ConfigBuilder: React.FC<ConfigBuilderProps> = () => {
  const [config, setConfig] = useState<ConfigBuilderState>(DEFAULT_BUILDER_STATE);
  const [activeOutputTab, setActiveOutputTab] = useState<'uri' | 'clash' | 'singbox'>('uri');
  const [copied, setCopied] = useState(false);
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [simulatedPing, setSimulatedPing] = useState<number | null>(null);
  const [isPinging, setIsPinging] = useState(false);
  const qrCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Computed Outputs
  const configURI = buildConfigURI(config);
  const clashYaml = buildClashMetaYaml(config);
  const singboxJson = buildSingboxJson(config);

  // Generate QR Code whenever URI changes
  useEffect(() => {
    QRCode.toDataURL(configURI, {
      width: 280,
      margin: 2,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    })
      .then((url) => {
        setQrDataUrl(url);
      })
      .catch((err) => {
        console.error('Error generating QR code', err);
      });
  }, [configURI]);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadQR = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `${config.remark || 'b4g-config'}-qr.png`;
    a.click();
  };

  const handleSimulatePing = () => {
    setIsPinging(true);
    setSimulatedPing(null);
    setTimeout(() => {
      // Calculate realistic ping based on protocol and port
      const basePing = config.protocol === 'hysteria2' ? 38 : config.security === 'reality' ? 44 : 56;
      const jitter = Math.floor(Math.random() * 12) - 4;
      setSimulatedPing(Math.max(28, basePing + jitter));
      setIsPinging(false);
    }, 900);
  };

  const handleGenerateNewUUID = () => {
    setConfig((prev) => ({
      ...prev,
      uuid: generateUUID(),
    }));
  };

  const handleGenerateRealityKeys = () => {
    setConfig((prev) => ({
      ...prev,
      shortId: generateShortId(8),
      publicKey: generateRandomSecret(43),
    }));
  };

  const applyPreset = (presetState: Partial<ConfigBuilderState>) => {
    setConfig((prev) => ({
      ...prev,
      ...presetState,
    }));
  };

  // Validation checks
  const isUUIDValid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(config.uuid);
  const isPortValid = config.port > 0 && config.port <= 65535;

  return (
    <section id="builder" className="py-12 bg-slate-950 text-slate-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-semibold mb-3">
            <Sliders className="w-3.5 h-3.5" />
            <span>استودیوی ساخت کانفیگ B4G</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            ژنراتور پیشرفته <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">ساخت و مهندسی کانفیگ</span>
          </h2>
          <p className="mt-2 text-sm text-slate-400">
            پروتکل دلخواه خود را بسازید، پارامترهای Reality، TLS، کلودفلر یا Hysteria 2 را تنظیم کنید و خروجی استاندارد URI، Clash یا Sing-box تحویل بگیرید.
          </p>
        </div>

        {/* Quick Presets Bar */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 mb-3">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>قالب‌های آماده و تست‌شده (پیش‌فرض پیشنهادی):</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {PRESET_CONFIGS.map((p, idx) => (
              <button
                key={idx}
                onClick={() => applyPreset(p.state)}
                className="p-3 text-right rounded-xl bg-slate-900/80 hover:bg-slate-850 border border-slate-800 hover:border-cyan-500/40 transition-all text-xs group relative overflow-hidden"
              >
                <div className="font-bold text-slate-200 group-hover:text-cyan-300 transition-colors flex items-center justify-between">
                  <span>{p.name}</span>
                  <span className="text-[10px] text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity">
                    اعمال ↵
                  </span>
                </div>
                <p className="text-slate-400 text-[11px] mt-1 leading-relaxed">{p.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Main Grid: Form on Left/Right, Output on other side */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Builder Form (7 cols on lg) */}
          <div className="lg:col-span-7 bg-slate-900/70 border border-slate-800/90 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6">
            
            {/* Protocol Tabs */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-2">
                انتخاب نوع پروتکل (Protocol Type)
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {(['vless', 'hysteria2', 'vmess', 'trojan', 'tuic', 'shadowsocks'] as ProtocolType[]).map((proto) => {
                  const isSelected = config.protocol === proto;
                  return (
                    <button
                      key={proto}
                      type="button"
                      onClick={() => setConfig({ ...config, protocol: proto })}
                      className={`py-2 px-2 text-center rounded-xl text-xs font-bold transition-all uppercase font-mono ${
                        isSelected
                          ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20 font-extrabold'
                          : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                      }`}
                    >
                      {proto}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Row: Remark & Server Address */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  نام کانفیگ / ریمارک (Remark)
                </label>
                <input
                  type="text"
                  value={config.remark}
                  onChange={(e) => setConfig({ ...config, remark: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors"
                  placeholder="B4G-GERMANY-REALITY⚡"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  آدرس سرور / دامنه / آی‌پی تمیز (Server Address)
                </label>
                <input
                  type="text"
                  value={config.server}
                  onChange={(e) => setConfig({ ...config, server: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 font-mono text-left focus:outline-none focus:border-cyan-500 transition-colors"
                  placeholder="de.b4g-network.live or IP"
                />
              </div>
            </div>

            {/* Row: Port & UUID */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-1">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>پورت (Port)</span>
                  {!isPortValid && <span className="text-[10px] text-rose-400">نامعتبر</span>}
                </label>
                <input
                  type="number"
                  value={config.port}
                  onChange={(e) => setConfig({ ...config, port: parseInt(e.target.value, 10) || 443 })}
                  className={`w-full bg-slate-950 border rounded-xl px-3.5 py-2.5 text-sm text-slate-100 font-mono text-left focus:outline-none ${
                    isPortValid ? 'border-slate-700/80 focus:border-cyan-500' : 'border-rose-500/70'
                  }`}
                  placeholder="443"
                />
              </div>

              <div className="sm:col-span-2">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-cyan-400" />
                    <span>کلید شناسایی UUID / رمز عبور</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleGenerateNewUUID}
                    className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>تولید تصادفی</span>
                  </button>
                </div>
                <input
                  type="text"
                  value={config.uuid}
                  onChange={(e) => setConfig({ ...config, uuid: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 font-mono text-left focus:outline-none focus:border-cyan-500"
                  placeholder="UUID یا رمز"
                />
              </div>
            </div>

            {/* Protocol Specific Sections */}
            {config.protocol === 'vless' && (
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-4">
                <div className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" />
                  <span>تنظیمات اختصاصی پروتکل VLESS</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Security Type */}
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      نوع امنیت (Security)
                    </label>
                    <select
                      value={config.security}
                      onChange={(e) => setConfig({ ...config, security: e.target.value as SecurityType })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                    >
                      <option value="reality">Reality (توصیه شده و فوق امن)</option>
                      <option value="tls">TLS استاندارد</option>
                      <option value="none">None (بدون رمزنگاری)</option>
                    </select>
                  </div>

                  {/* Transport */}
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      ترنسپورت (Transport)
                    </label>
                    <select
                      value={config.transport}
                      onChange={(e) => setConfig({ ...config, transport: e.target.value as TransportType })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                    >
                      <option value="tcp">TCP (بهترین برای Reality)</option>
                      <option value="ws">WebSocket (بهترین برای کلودفلر CDN)</option>
                      <option value="grpc">gRPC (مقاوم در برابر اختلال)</option>
                      <option value="httpupgrade">HTTPUpgrade</option>
                    </select>
                  </div>
                </div>

                {/* Reality Details */}
                {config.security === 'reality' && (
                  <div className="pt-2 border-t border-slate-800/80 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-semibold text-slate-400">
                        پارامترهای XTLS Reality
                      </span>
                      <button
                        type="button"
                        onClick={handleGenerateRealityKeys}
                        className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                      >
                        <RefreshCw className="w-3 h-3" />
                        <span>تولید کلید و Short ID جدید</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">Public Key (pbk)</label>
                        <input
                          type="text"
                          value={config.publicKey}
                          onChange={(e) => setConfig({ ...config, publicKey: e.target.value })}
                          className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono text-left focus:outline-none focus:border-cyan-500"
                          placeholder="Public Key"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">Short ID (sid)</label>
                        <input
                          type="text"
                          value={config.shortId}
                          onChange={(e) => setConfig({ ...config, shortId: e.target.value })}
                          className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono text-left focus:outline-none focus:border-cyan-500"
                          placeholder="Short ID"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">فینگرپرینت (uTLS Fingerprint)</label>
                        <select
                          value={config.fingerprint}
                          onChange={(e) => setConfig({ ...config, fingerprint: e.target.value as FingerprintType })}
                          className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                        >
                          <option value="chrome">Chrome (پیشنهادی)</option>
                          <option value="firefox">Firefox</option>
                          <option value="safari">Safari</option>
                          <option value="ios">iOS</option>
                          <option value="random">Random</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">جریان ترافیک (Flow)</label>
                        <select
                          value={config.flow}
                          onChange={(e) => setConfig({ ...config, flow: e.target.value as 'xtls-rprx-vision' | 'none' })}
                          className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono text-left focus:outline-none focus:border-cyan-500"
                        >
                          <option value="xtls-rprx-vision">xtls-rprx-vision</option>
                          <option value="none">none</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {/* WebSocket Specifics */}
                {config.transport === 'ws' && (
                  <div className="pt-2 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">WS Path</label>
                      <input
                        type="text"
                        value={config.path}
                        onChange={(e) => setConfig({ ...config, path: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono text-left focus:outline-none"
                        placeholder="/ws-path"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">WS Host Header</label>
                      <input
                        type="text"
                        value={config.host}
                        onChange={(e) => setConfig({ ...config, host: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono text-left focus:outline-none"
                        placeholder="worker.domain.com"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Hysteria 2 Specifics */}
            {config.protocol === 'hysteria2' && (
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
                <div className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                  <Zap className="w-4 h-4" />
                  <span>تنظیمات فوق‌العاده سریع پروتکل Hysteria 2</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-slate-300 mb-1">
                      بازه پورت هاپینگ (Port Hopping Range)
                    </label>
                    <input
                      type="text"
                      value={config.hy2PortHop}
                      onChange={(e) => setConfig({ ...config, hy2PortHop: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono text-left focus:outline-none focus:border-amber-400"
                      placeholder="20000:50000"
                    />
                    <p className="text-[10px] text-slate-500 mt-1">تغییر خودکار پورت جهت جلوگیری از بلاک UDP اپراتورها</p>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-300 mb-1">
                      استتار سالاماندر (Salamander Obfs)
                    </label>
                    <input
                      type="text"
                      value={config.hy2ObfsPassword}
                      onChange={(e) => setConfig({ ...config, hy2ObfsPassword: e.target.value, hy2Obfs: e.target.value ? 'salamander' : '' })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono text-left focus:outline-none focus:border-amber-400"
                      placeholder="رمز Obfs (اختیاری)"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* SNI / Camouflage Selection */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-cyan-400" />
                  <span>دامنه استتار SNI (Server Name Indication)</span>
                </label>
                <span className="text-[11px] text-slate-400">ترافیک به عنوان این سایت دیده می‌شود</span>
              </div>
              
              <div className="flex gap-2">
                <input
                  type="text"
                  value={config.sni}
                  onChange={(e) => setConfig({ ...config, sni: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2 text-sm text-slate-100 font-mono text-left focus:outline-none focus:border-cyan-500"
                  placeholder="speedtest.net"
                />
              </div>

              {/* Quick SNI tags */}
              <div className="flex flex-wrap items-center gap-1.5 mt-2">
                <span className="text-[10px] text-slate-500">پیشنهادی:</span>
                {POPULAR_SNI_LIST.map((item) => (
                  <button
                    key={item.domain}
                    type="button"
                    onClick={() => setConfig({ ...config, sni: item.domain })}
                    className={`text-[11px] px-2 py-0.5 rounded-lg border transition-colors ${
                      config.sni === item.domain
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                        : 'bg-slate-800/60 text-slate-400 border-slate-700 hover:text-slate-200'
                    }`}
                  >
                    {item.domain}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Real-time Output & QR Code (5 cols on lg) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-2xl relative overflow-hidden">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <h3 className="font-bold text-sm text-white">خروجی تولید شده B4G</h3>
                </div>

                {/* Simulated Ping Tool */}
                <button
                  type="button"
                  onClick={handleSimulatePing}
                  disabled={isPinging}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-mono transition-colors"
                >
                  <Radio className={`w-3 h-3 text-cyan-400 ${isPinging ? 'animate-spin' : ''}`} />
                  <span>
                    {isPinging ? 'تست پینگ...' : simulatedPing ? `${simulatedPing} ms` : 'تست پینگ'}
                  </span>
                </button>
              </div>

              {/* Output Format Switcher */}
              <div className="flex rounded-xl bg-slate-950 p-1 border border-slate-800 mb-4">
                <button
                  type="button"
                  onClick={() => setActiveOutputTab('uri')}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
                    activeOutputTab === 'uri'
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  لینک کانفیگ (URI)
                </button>
                <button
                  type="button"
                  onClick={() => setActiveOutputTab('clash')}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
                    activeOutputTab === 'clash'
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  کد Clash.Meta
                </button>
                <button
                  type="button"
                  onClick={() => setActiveOutputTab('singbox')}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
                    activeOutputTab === 'singbox'
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  کانفیگ Sing-box
                </button>
              </div>

              {/* Code Box */}
              <div className="relative">
                <pre className="w-full h-44 overflow-y-auto bg-slate-950 border border-slate-800/90 rounded-xl p-3 text-xs text-cyan-300 font-mono select-all break-all whitespace-pre-wrap leading-relaxed">
                  {activeOutputTab === 'uri' && configURI}
                  {activeOutputTab === 'clash' && clashYaml}
                  {activeOutputTab === 'singbox' && singboxJson}
                </pre>

                {/* Quick copy overlay button */}
                <button
                  type="button"
                  onClick={() => {
                    const textToCopy =
                      activeOutputTab === 'uri'
                        ? configURI
                        : activeOutputTab === 'clash'
                        ? clashYaml
                        : singboxJson;
                    handleCopy(textToCopy);
                  }}
                  className="absolute top-2 left-2 flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-white text-xs font-medium backdrop-blur transition-all border border-slate-700 shadow-md"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">کپی شد!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-300" />
                      <span>کپی</span>
                    </>
                  )}
                </button>
              </div>

              {/* QR Code and Actions */}
              <div className="mt-5 pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center gap-4">
                {/* QR Code thumbnail */}
                <div 
                  className="bg-white p-2 rounded-xl shadow-md cursor-pointer hover:opacity-90 transition-opacity flex-shrink-0"
                  onClick={() => setQrModalOpen(true)}
                  title="کلیک جهت بزرگ‌نمایی کیوآرکد"
                >
                  {qrDataUrl ? (
                    <img src={qrDataUrl} alt="B4G Config QR Code" className="w-24 h-24 rounded-lg" />
                  ) : (
                    <div className="w-24 h-24 flex items-center justify-center bg-slate-200 rounded-lg">
                      <QrCode className="w-8 h-8 text-slate-600" />
                    </div>
                  )}
                </div>

                {/* Actions & Instructions */}
                <div className="flex-1 space-y-2 text-right">
                  <h4 className="text-xs font-bold text-slate-200">اسکن مستقیم با گوشی</h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    با دوربین اپلیکیشن v2rayNG، Streisand، FoXray یا Sing-box اسکن کنید تا کانفیگ فوراً اضافه شود.
                  </p>
                  
                  <div className="flex flex-wrap gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setQrModalOpen(true)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
                    >
                      <QrCode className="w-3.5 h-3.5 text-cyan-400" />
                      <span>بزرگ‌نمایی QR</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleDownloadQR}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
                    >
                      <Download className="w-3.5 h-3.5 text-cyan-400" />
                      <span>ذخیره تصویر QR</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Real-time Health Diagnostics */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-1.5 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>فرمت صحیح استاندارد Xray Core</span>
                </div>
                <div className="text-slate-400 font-mono">
                  Port: {config.port} | {config.security.toUpperCase()}
                </div>
              </div>

            </div>

            {/* Help Callout */}
            <div className="p-4 rounded-xl bg-cyan-950/20 border border-cyan-800/30 text-xs text-slate-300 leading-relaxed">
              <div className="font-bold text-cyan-400 mb-1 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4" />
                <span>نکته مهندسی کانفیگ‌های ضد فیلتر B4G:</span>
              </div>
              در پروتکل VLESS Reality، مطمئن شوید پورتی که روی سرور باز کرده‌اید (معمولاً ۴۴۳) با پورت کانفیگ یکی باشد و دامنه SNI فیلتر نباشد. با این ترکیب، ترافیک شما هیچ‌گونه نشانه‌ای از پروکسی به فایروال‌های DPI نشان نمی‌دهد.
            </div>

          </div>

        </div>

      </div>

      {/* QR Code Fullscreen Modal */}
      {qrModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-sm w-full text-center space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="text-sm font-bold text-white font-mono">B4G QR Scanner</div>
              <button
                onClick={() => setQrModalOpen(false)}
                className="text-slate-400 hover:text-white text-lg font-bold p-1"
              >
                ✕
              </button>
            </div>

            <div className="bg-white p-4 rounded-2xl inline-block mx-auto shadow-inner">
              {qrDataUrl && <img src={qrDataUrl} alt="B4G Config QR" className="w-64 h-64 mx-auto" />}
            </div>

            <div className="text-xs text-slate-300 font-medium break-words font-mono bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              {config.remark}
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleDownloadQR}
                className="flex-1 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>دانلود عکس کیوآرکد</span>
              </button>
              <button
                onClick={() => {
                  handleCopy(configURI);
                  setQrModalOpen(false);
                }}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <Copy className="w-4 h-4" />
                <span>کپی لینک</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
