import React, { useState } from 'react';
import { Activity, Signal, Wifi, CheckCircle2, ArrowUpRight, Play, RefreshCw, Server } from 'lucide-react';
import { OPERATOR_STATUSES } from '../data/mockData';

export const OperatorStatusSection: React.FC = () => {
  const [testingPing, setTestingPing] = useState(false);
  const [pings, setPings] = useState<{ [key: string]: number }>({
    mci: 48,
    irancell: 42,
    mokhaberat: 37,
    rightel: 54,
  });

  const runLatencyTest = () => {
    setTestingPing(true);
    setTimeout(() => {
      setPings({
        mci: Math.floor(Math.random() * 10) + 42,
        irancell: Math.floor(Math.random() * 8) + 38,
        mokhaberat: Math.floor(Math.random() * 6) + 34,
        rightel: Math.floor(Math.random() * 12) + 48,
      });
      setTestingPing(false);
    }, 1200);
  };

  return (
    <section id="operators" className="py-14 bg-slate-900/50 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-semibold mb-2">
              <Activity className="w-3.5 h-3.5" />
              <span>پایش لحظه‌ای شبکه اینترنت کشور</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              وضعیت اتصال و <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">بهترین پروتکل به تفکیک اپراتور</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              تیم رصد شبکه B4G پیوسته رفتار فیلترینگ اپراتورها را بررسی کرده و بهترین پیکربندی را پیشنهاد می‌دهد.
            </p>
          </div>

          <button
            onClick={runLatencyTest}
            disabled={testingPing}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold transition-all self-start md:self-auto"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${testingPing ? 'animate-spin' : ''}`} />
            <span>{testingPing ? 'در حال سنجش پینگ زنده...' : 'سنجش مجدد پینگ اپراتورها'}</span>
          </button>
        </div>

        {/* Operator Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {OPERATOR_STATUSES.map((op) => {
            const currentPing = pings[op.code] || 45;
            return (
              <div
                key={op.code}
                className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800/90 shadow-lg space-y-4 relative overflow-hidden"
              >
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-sm text-white">{op.name}</span>
                  <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    <span>{op.statusText}</span>
                  </span>
                </div>

                <div className="space-y-2 text-xs">
                  <div>
                    <span className="text-slate-500 text-[11px] block">پروتکل پیشنهادی امروز:</span>
                    <span className="font-bold text-cyan-300">{op.bestProtocol}</span>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-900 text-slate-400">
                    <span>پورت بهینه:</span>
                    <span className="font-mono font-bold text-slate-200">{op.recommendedPort}</span>
                  </div>

                  <div className="flex items-center justify-between text-slate-400">
                    <span>پینگ میانگین:</span>
                    <span className="font-mono font-bold text-emerald-400">{currentPing} ms</span>
                  </div>
                </div>

                {/* Latency Visual Bar */}
                <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-emerald-400 to-cyan-500 h-full rounded-full transition-all duration-700"
                    style={{ width: `${Math.max(20, Math.min(100, 120 - currentPing))}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
