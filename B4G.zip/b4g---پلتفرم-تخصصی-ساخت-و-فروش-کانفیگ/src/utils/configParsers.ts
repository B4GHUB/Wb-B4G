import { ConfigBuilderState, ProtocolType } from '../types';

export function generateUUID(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

export function generateShortId(length = 8): string {
  const chars = '0123456789abcdef';
  let res = '';
  for (let i = 0; i < length; i++) {
    res += chars[Math.floor(Math.random() * chars.length)];
  }
  return res;
}

export function generateRandomSecret(length = 16): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let res = '';
  for (let i = 0; i < length; i++) {
    res += chars[Math.floor(Math.random() * chars.length)];
  }
  return res;
}

export function buildConfigURI(state: ConfigBuilderState): string {
  const remark = encodeURIComponent(state.remark.trim() || 'B4G-Custom-Config');
  const server = state.server.trim() || '127.0.0.1';
  const port = state.port || 443;
  const uuid = state.uuid.trim() || '11111111-2222-3333-4444-555555555555';

  if (state.protocol === 'vless') {
    const params = new URLSearchParams();
    params.set('type', state.transport);
    
    if (state.security === 'reality') {
      params.set('security', 'reality');
      if (state.publicKey) params.set('pbk', state.publicKey.trim());
      if (state.fingerprint) params.set('fp', state.fingerprint);
      if (state.sni) params.set('sni', state.sni.trim());
      if (state.shortId) params.set('sid', state.shortId.trim());
      if (state.spiderX) params.set('spx', state.spiderX.trim() || '%2F');
      if (state.flow === 'xtls-rprx-vision') params.set('flow', 'xtls-rprx-vision');
    } else if (state.security === 'tls') {
      params.set('security', 'tls');
      if (state.sni) params.set('sni', state.sni.trim());
      if (state.fingerprint) params.set('fp', state.fingerprint);
      if (state.alpn) params.set('alpn', state.alpn.trim());
      if (state.flow === 'xtls-rprx-vision') params.set('flow', 'xtls-rprx-vision');
    } else {
      params.set('security', 'none');
    }

    if (state.transport === 'ws') {
      if (state.path) params.set('path', state.path.trim());
      if (state.host) params.set('host', state.host.trim());
    } else if (state.transport === 'grpc') {
      if (state.serviceName) params.set('serviceName', state.serviceName.trim());
      params.set('mode', 'gun');
    } else if (state.transport === 'httpupgrade') {
      if (state.path) params.set('path', state.path.trim());
      if (state.host) params.set('host', state.host.trim());
    }

    return `vless://${uuid}@${server}:${port}?${params.toString()}#${remark}`;
  }

  if (state.protocol === 'vmess') {
    const vmessObj = {
      v: '2',
      ps: state.remark || 'B4G-VMess',
      add: server,
      port: String(port),
      id: uuid,
      aid: '0',
      scy: 'auto',
      net: state.transport === 'ws' ? 'ws' : state.transport === 'grpc' ? 'grpc' : 'tcp',
      type: 'none',
      host: state.host || state.sni || '',
      path: state.path || '/',
      tls: state.security === 'tls' ? 'tls' : '',
      sni: state.sni || '',
      alpn: state.alpn || ''
    };
    const jsonStr = JSON.stringify(vmessObj);
    const b64 = typeof window !== 'undefined' ? window.btoa(unescape(encodeURIComponent(jsonStr))) : Buffer.from(jsonStr).toString('base64');
    return `vmess://${b64}`;
  }

  if (state.protocol === 'trojan') {
    const params = new URLSearchParams();
    if (state.security === 'reality') {
      params.set('security', 'reality');
      if (state.publicKey) params.set('pbk', state.publicKey.trim());
      if (state.fingerprint) params.set('fp', state.fingerprint);
      if (state.sni) params.set('sni', state.sni.trim());
      if (state.shortId) params.set('sid', state.shortId.trim());
    } else if (state.security === 'tls') {
      params.set('security', 'tls');
      if (state.sni) params.set('sni', state.sni.trim());
      if (state.alpn) params.set('alpn', state.alpn.trim());
    }

    params.set('type', state.transport);
    if (state.transport === 'ws') {
      if (state.path) params.set('path', state.path.trim());
      if (state.host) params.set('host', state.host.trim());
    } else if (state.transport === 'grpc') {
      if (state.serviceName) params.set('serviceName', state.serviceName.trim());
    }

    return `trojan://${uuid}@${server}:${port}?${params.toString()}#${remark}`;
  }

  if (state.protocol === 'hysteria2') {
    const params = new URLSearchParams();
    if (state.sni) params.set('sni', state.sni.trim());
    if (state.hy2Obfs) {
      params.set('obfs', state.hy2Obfs);
      if (state.hy2ObfsPassword) params.set('obfs-password', state.hy2ObfsPassword);
    }
    if (state.hy2PortHop) {
      params.set('mport', state.hy2PortHop);
    }
    params.set('insecure', '0');
    return `hysteria2://${uuid}@${server}:${port}?${params.toString()}#${remark}`;
  }

  if (state.protocol === 'tuic') {
    const params = new URLSearchParams();
    params.set('congestion_control', 'bbr');
    params.set('alpn', state.alpn || 'h3');
    if (state.sni) params.set('sni', state.sni.trim());
    return `tuic://${uuid}:${state.shortId || 'secret'}@${server}:${port}?${params.toString()}#${remark}`;
  }

  if (state.protocol === 'shadowsocks') {
    const method = state.ssMethod || '2022-blake3-aes-128-gcm';
    const auth = `${method}:${uuid}`;
    const b64Auth = typeof window !== 'undefined' ? window.btoa(auth) : Buffer.from(auth).toString('base64');
    return `ss://${b64Auth}@${server}:${port}#${remark}`;
  }

  return `vless://${uuid}@${server}:${port}#${remark}`;
}

export function buildClashMetaYaml(state: ConfigBuilderState): string {
  const name = state.remark.trim() || 'B4G-Proxy';
  const server = state.server.trim() || '127.0.0.1';
  const port = state.port || 443;
  const uuid = state.uuid.trim() || 'uuid-placeholder';

  if (state.protocol === 'vless') {
    return `- name: "${name}"
  type: vless
  server: ${server}
  port: ${port}
  uuid: ${uuid}
  network: ${state.transport}
  tls: ${state.security !== 'none'}
  udp: true
  ${state.flow === 'xtls-rprx-vision' ? 'flow: xtls-rprx-vision\n  ' : ''}${state.sni ? `servername: ${state.sni}\n  ` : ''}${state.security === 'reality' ? `reality-opts:\n    public-key: ${state.publicKey || 'PUBLIC_KEY'}\n    short-id: "${state.shortId || ''}"\n  client-fingerprint: ${state.fingerprint}` : `client-fingerprint: ${state.fingerprint}`}
  ${state.transport === 'ws' ? `ws-opts:\n    path: "${state.path || '/'}"\n    headers:\n      Host: "${state.host || state.sni || ''}"` : ''}
  ${state.transport === 'grpc' ? `grpc-opts:\n    grpc-service-name: "${state.serviceName || 'grpc'}"` : ''}`;
  }

  if (state.protocol === 'hysteria2') {
    return `- name: "${name}"
  type: hysteria2
  server: ${server}
  port: ${port}
  password: ${uuid}
  sni: ${state.sni || server}
  skip-cert-verify: false
  ${state.hy2PortHop ? `ports: ${state.hy2PortHop}\n  ` : ''}alpn:
    - h3`;
  }

  if (state.protocol === 'trojan') {
    return `- name: "${name}"
  type: trojan
  server: ${server}
  port: ${port}
  password: ${uuid}
  udp: true
  sni: ${state.sni || server}
  ${state.transport === 'ws' ? `network: ws\n  ws-opts:\n    path: "${state.path || '/'}"` : ''}`;
  }

  return `# B4G Clash Node
- name: "${name}"
  type: ${state.protocol}
  server: ${server}
  port: ${port}`;
}

export function buildSingboxJson(state: ConfigBuilderState): string {
  const server = state.server.trim() || '127.0.0.1';
  const port = state.port || 443;
  const uuid = state.uuid.trim() || 'uuid-placeholder';

  const outbound: Record<string, unknown> = {
    type: state.protocol,
    tag: state.remark || 'B4G-Outbound',
    server: server,
    server_port: port,
  };

  if (state.protocol === 'vless') {
    outbound.uuid = uuid;
    if (state.flow === 'xtls-rprx-vision') outbound.flow = 'xtls-rprx-vision';
    if (state.transport === 'ws') {
      outbound.transport = {
        type: 'ws',
        path: state.path || '/',
        headers: { Host: state.host || state.sni || '' }
      };
    } else if (state.transport === 'grpc') {
      outbound.transport = {
        type: 'grpc',
        service_name: state.serviceName || 'grpc'
      };
    }
    if (state.security === 'reality') {
      outbound.tls = {
        enabled: true,
        server_name: state.sni || '',
        utls: { enabled: true, fingerprint: state.fingerprint },
        reality: {
          enabled: true,
          public_key: state.publicKey || '',
          short_id: state.shortId || ''
        }
      };
    } else if (state.security === 'tls') {
      outbound.tls = {
        enabled: true,
        server_name: state.sni || '',
        utls: { enabled: true, fingerprint: state.fingerprint }
      };
    }
  }

  return JSON.stringify(outbound, null, 2);
}

export interface ParsedConfig {
  protocol: ProtocolType | 'unknown';
  remark: string;
  server: string;
  port: number;
  uuid: string;
  security: string;
  transport: string;
  sni: string;
  host: string;
  path: string;
  raw: string;
}

export function parseConfigURI(raw: string): ParsedConfig {
  const trimmed = raw.trim();
  const defaultRes: ParsedConfig = {
    protocol: 'unknown',
    remark: '',
    server: '',
    port: 0,
    uuid: '',
    security: '',
    transport: '',
    sni: '',
    host: '',
    path: '',
    raw: trimmed
  };

  if (!trimmed) return defaultRes;

  try {
    if (trimmed.startsWith('vless://') || trimmed.startsWith('trojan://') || trimmed.startsWith('hysteria2://') || trimmed.startsWith('hy2://')) {
      const urlPart = trimmed.replace('hy2://', 'hysteria2://');
      const hashSplit = urlPart.split('#');
      const remark = hashSplit[1] ? decodeURIComponent(hashSplit[1]) : '';
      const mainUrl = hashSplit[0];

      const match = mainUrl.match(/^([a-z0-9]+):\/\/([^@]+)@([^:?]+)(?::(\d+))?(?:\?(.*))?$/);
      if (match) {
        const protoStr = match[1] === 'hysteria2' ? 'hysteria2' : (match[1] as ProtocolType);
        const uuid = match[2];
        const server = match[3];
        const port = match[4] ? parseInt(match[4], 10) : 443;
        const query = match[5] || '';
        const params = new URLSearchParams(query);

        return {
          protocol: protoStr,
          remark,
          server,
          port,
          uuid,
          security: params.get('security') || (protoStr === 'hysteria2' ? 'tls' : 'none'),
          transport: params.get('type') || 'tcp',
          sni: params.get('sni') || '',
          host: params.get('host') || '',
          path: params.get('path') || '',
          raw: trimmed
        };
      }
    }

    if (trimmed.startsWith('vmess://')) {
      const b64 = trimmed.substring(8);
      let decodedStr = '';
      try {
        decodedStr = decodeURIComponent(escape(window.atob(b64)));
      } catch {
        decodedStr = window.atob(b64);
      }
      const obj = JSON.parse(decodedStr);
      return {
        protocol: 'vmess',
        remark: obj.ps || '',
        server: obj.add || '',
        port: parseInt(obj.port, 10) || 443,
        uuid: obj.id || '',
        security: obj.tls || 'none',
        transport: obj.net || 'tcp',
        sni: obj.sni || '',
        host: obj.host || '',
        path: obj.path || '',
        raw: trimmed
      };
    }
  } catch (e) {
    console.error('Failed to parse config:', e);
  }

  return defaultRes;
}
